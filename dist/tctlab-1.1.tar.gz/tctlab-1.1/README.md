# tctlab

Welcome to TCTLab, a python module for controlling the TCT setup at Syracuse University. 

## installation

To install the package, run

```python -m pip install --index-url https://test.pypi.org/simple --no-deps tctlab```