# tctlab

Welcome to TCTLab, a python module for controlling the TCT setup at Syracuse University. 

## installation

To install the package, run

```pip install -e PATH/TO/PACKAGE```